import React, {Component} from 'react';

class Footer extends Component {
  render() {
    return (
      <div className="container">
        <footer className="footer">
          <p>&copy; 2017 Carimus, Inc.</p>
        </footer>
      </div>
    );
  }
}

export default Footer;
